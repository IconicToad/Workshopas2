import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stats-information',
  templateUrl: './stats-information.component.html',
  styleUrls: ['./stats-information.component.scss']
})
export class StatsInformationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
