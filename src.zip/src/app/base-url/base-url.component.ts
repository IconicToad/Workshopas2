import { Component, OnInit } from '@angular/core';
import { AppService } from '../services/app.service';

@Component({
  selector: 'app-base-url',
  templateUrl: './base-url.component.html',
  styleUrls: ['./base-url.component.scss']
})
export class BaseUrlComponent implements OnInit {
  public input: string = 'https://dev-games-backend.advbet.com/v1/ab-roulette/1';

  constructor(private appService: AppService) { }

  ngOnInit(): void {
  }

  public changeInput(){
    console.log(this.input);
    this.appService.getConfiguration(this.input);
  }

}

